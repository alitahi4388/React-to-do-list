import React from 'react';

const Footer = () => {
  return (
    <footer className="footer">
      <p>21007105014 Mehmood Ahmed Khan BS.IT Batch-7</p>
    </footer>
  );
};

export default Footer;
